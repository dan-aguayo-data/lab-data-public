import sys
import os
import re
import gzip
import logging
from ..models import DATABASELOG_HEADER, META_HEADER, DDL_HEADER ,FILE_FORMAT, FILE_SETTINGS
from csv import reader, writer, field_size_limit

logger = logging.getLogger(__name__)

max_int = sys.maxsize
while True:
    # decrease the maxInt value by factor 10 
    # as long as the OverflowError occurs.
    try:
        field_size_limit(max_int)
        break
    except OverflowError:
        max_int = int(max_int/10)

FILE_FLUSH_AFTER = 100000
DATABASELOG_STATEMENT_INDEX = DATABASELOG_HEADER.index('SQL_STATEMENT')
META_HEADER_STATEMENT_INDEX = META_HEADER.index('QUERY_CODE')
DDL_HEADER_STATEMENT_INDEX = DDL_HEADER.index('OBJECT_DDL')
### select comments
# single-line style --
# multi-line style /*  ... */
REGEX_SQL_COMMENTS = re.compile(r'(--.*)|(((\/\*)+?[\w\W]+?(\*\/)+))')
### select any whitespace
REGEX_WHITESPACE = re.compile(r"\s+")
### select escaped single quotes \'
REGEX_ESCAPE_SINGLE_QUOTE = re.compile(r"\\(?<=\\)'")
### select literals inside single quotes
REGEX_SINGLE_QUOTE_LITERALS = re.compile(r"{[^{^}]*}|'[^']*'|N'[^']*'")
### select special operators
REGEX_OPERATORS = re.compile(r"[()<>=,!]+")

class MaskerException(Exception):
    pass

def header_validation(input_header, expected_header):
    header = [x.upper() for x in input_header]
    return header == expected_header

def pad_operators(re_token):
  return ' ' + re_token.group(0) + ' '

def mask_ops(query):
    query = query.replace('\r', '\n')
    query = REGEX_SQL_COMMENTS.sub('',query)
    query = REGEX_WHITESPACE.sub(' ', query).strip()
    query = REGEX_ESCAPE_SINGLE_QUOTE.sub('', query)
    query = REGEX_SINGLE_QUOTE_LITERALS.sub("''", query)
    query = REGEX_OPERATORS.sub(pad_operators, query)
    return ' '.join([ '1' if tk.isnumeric() else tk for tk in query.split()])

def mask(input_path: str='./input', output_path: str='./output'):
    """
    input_path: Path to the directory containing the DATABASELOG_YYYYMMDDHHMMSS.csv or META_YYYYMMDDHHMMSS.csv or DDL_YYYYMMDDHHMMSS.csv files
    output_path: Optional: Path to the directory which for outputting masked DATABASELOG_*.csv or META_*.csv or DDL_*.csv files
    """
    os.makedirs(output_path, exist_ok=True)

    if input_path == output_path:
        raise MaskerException("Input file directory cannot be the same as output.")

    logger.info('Scanning input path {} for valid files:'.format(input_path))
    for f in os.listdir(input_path):
        file_path = os.path.join(input_path, f)
        if os.path.isfile(file_path) and (f.startswith('META_') or f.startswith('DATABASELOG_') or f.startswith('DDL_')) and (f.endswith('.csv') or f.endswith('.csv.gz')):
            logger.info('{} ... masking ...'.format(f))
        else:
            logger.info('{} ... skipping not applicable ...'.format(f))
            continue
        if f.startswith('META_'):
            expected_header = META_HEADER
            statement_index = META_HEADER_STATEMENT_INDEX
        elif f.startswith('DDL'):
            expected_header = DDL_HEADER
            statement_index = DDL_HEADER_STATEMENT_INDEX
        else: # DATABASE_*
            expected_header = DATABASELOG_HEADER
            statement_index = DATABASELOG_STATEMENT_INDEX 
        logger.info("Processing: {}".format(file_path))
        log = open(file_path, 'rt', **FILE_SETTINGS) if file_path.endswith('.csv') else gzip.open(file_path, 'rt', **FILE_SETTINGS)
        log_reader = reader(log, **FILE_FORMAT)
        input_header = next(log_reader, [])
        if not header_validation(input_header, expected_header):
            raise MaskerException("Header does not match expected, expected:{}".format(expected_header))

        out_file_path = os.path.join(output_path, f)
        output_file = open(out_file_path, 'wt', **FILE_SETTINGS) if file_path.endswith('.csv') else gzip.open(out_file_path, 'wt', **FILE_SETTINGS)
        out_writer = writer(output_file, **FILE_FORMAT)
        out_writer.writerows([input_header])
        buf = []
        n = 0
        for row in log_reader:
            row[statement_index] = mask_ops(row[statement_index])
            buf.append(row)
            n += 1
            if n % FILE_FLUSH_AFTER == 0:
                logger.info("{} rows processed".format(n))
                out_writer.writerows(buf)
                buf = []
        out_writer.writerows(buf)
        output_file.close()
        logger.info("Output: {}".format(out_file_path))
        log.close()