import csv
import gzip
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def clean_key(input):
    return input.replace(']', '').replace('[', '').replace('"', '').replace('.', '_').lower()

#TODO: Below needs to be completely reworked
# KADA EVENT ACTIONS
class KEvents(object):
    VIEWED = 'VIEWED'
    CREATOR = 'CREATOR'
    MODIFIED = 'MODIFIED'
    EXECUTED = 'EXECUTED'

# KADA OBJECT TYPES
class KTypes(object):
    WORKSPACE = 'WORKSPACE'
    CONTENT = 'CONTENT'
    CONTENT_CHILD = 'CONTENT_CHILD'
    CONTENT_APP = 'CONTENT_APP'
    DATAPIPELINE = 'DATA_PIPELINE'
    DATASET = 'DATASET'
    DATASET_TABLE = 'DATASET_TABLE'
    DATASET_FIELD = 'DATASET_FIELD'
    USER = 'USER'
    FILE = 'FILE'
    STORAGE = 'STORAGE'
    DATABASE = 'DATABASE'
    SCHEMA = 'SCHEMA'
    TABLE = 'TABLE'
    COLUMN = 'COLUMN'
    QUERY = 'QUERY'
    ISSUE = 'ISSUE'
    MACRO = 'MACRO'
    PROCEDURE = 'PROCEDURE'

class KRels(object):
    OWNER_OF = 'OWNER_OF_SRC'
    REFERENCES = 'REFERENCES'
    CREATOR_OF = 'CREATOR_OF_SRC'
    VERIFIES = 'VERIFIES_SRC'
    IMPACTS = 'IMPACTS_SRC'
    CHILD_OF = 'CHILD_OF'

class KProps(object):
    BOOLEAN = 'BOOLEAN'
    STRING = 'STRING'
    INTEGER = 'INTEGER'
    JSON = 'JSON'

FILE_FORMAT = {
    'delimiter': '|',
    'quotechar': '"',
    'quoting': csv.QUOTE_ALL,
    'doublequote': True,
    'strict': True,
    'skipinitialspace': False
}

METADATA_HEADER = ['DATABASENAME', 'TYPE', 'SCHEMANAME', 'TABLENAME', 'COLUMNNAME',
                   'DATATYPE', 'NULLABLE']
METADATA_FILE = 'METADATA_{}.csv'

METADATA_KEYS_HEADER = ['DATABASENAME', 'TYPE', 'SCHEMANAME', 'TABLENAME', 'COLUMNNAME',
                   'PRIMARY_KEY_FLAG', 'FOREIGN_KEY_TARGET_SCHEMANAME', 'FOREIGN_KEY_TARGET_TABLENAME', 'FOREIGN_KEY_TARGET_COLUMNNAME', 'PARTITION_KEY_FLAG']
METADATA_KEYS_FILE = 'METADATA_KEYS_{}.csv'

DATABASELOG_HEADER = ['DATABASENAME', 'EXECUTION_TIME', 'QUERY_ID', 'USERNAME',
                      'USER_ID', 'SCHEMANAME', 'HOST_ID', 'APP_ID', 'CLIENT_ID',
                      'CLIENT_ADDRESS', 'SQL_STATEMENT', 'RUNTIME',
                      'ROW_COUNT', 'SESSION_ID', 'SESSION_START_TIME',
                      'SESSION_SOURCE', 'PROXY_USERNAME', 'PROXY_ROLE',
                      'COMPUTE_ID', 'COMPUTE_NAME', 'SQL_ROW_NO']
DATABASELOG_FILE = 'DATABASELOG_{}_{}.csv'

DATABASE_ROLE_HEADER = ['OBJECT_TYPE', 'OBJECT_ID', 'USER', 'ROLE']

DATABASE_ROLE_FILE = 'ROLES_{}.csv'

DDL_HEADER = ['DATABASENAME','OBJECT_TYPE', 'SCHEMANAME', 'OBJECT_NAME', 'OBJECT_DDL']

DDL_FILE = 'DDL_{}.csv'

DDL_METADATA_HEADER = ['DATABASENAME', 'SCHEMANAME', 'OBJECT_NAME', 'OBJECT_VERSION',
                       'OBJECT_TYPE', 'CREATE_USERNAME', 'CREATE_TIMESTAMP',
                       'UPDATE_USERNAME', 'UPDATE_TIMESTAMP', 'ACCESS_COUNT',
                       'LAST_ACCESS_TIMESTAMP']
DDL_METADATA_FILE = 'DDLMETADATA_{}.csv'

USER_HEADER = ['USERNAME', 'FIRST_NAME',
               'LAST_NAME', 'EMAIL', 'IS_SYSTEM', 'USER_ID']
USERS_FILE = 'USERS_{}.csv'

META_HEADER = ['OBJECT_TYPE', 'OBJECT_ID', 'TOOL_OBJECT_TYPE', 'NAME', 'DESCRIPTION',
               'URL', 'PATH', 'QUERY_CODE', 'CREATED_AT', 'UPDATED_AT', 'LAST_RUN_AT']
META_FILE = 'META_{}.csv'

LINK_HEADER = ['SRC_OBJECT_TYPE', 'SRC_OBJECT_ID',
               'TRG_OBJECT_TYPE', 'TRG_OBJECT_ID', 'RELATIONSHIP']
LINK_FILE = 'LINKAGES_{}.csv'

EVENT_HEADER = ['EXECUTION_TIME', 'OBJECT_TYPE',
                'OBJECT_ID', 'EVENT', 'USERNAME']
EVENT_FILE = 'EVENTS_{}.csv'

FILE_SETTINGS = {'encoding': 'utf-8', 'newline': '\n'}

IDP_USER_HEADER = ['USERNAME', 'FIRST_NAME',
                'LAST_NAME', 'EMAIL', 'DESCRIPTION', 'IS_SYSTEM_USER',
                'IS_LOGIN_USER', 'ROLES', 'GROUP_NAME',
                'USER_ID']
IDP_USERS_FILE = 'USERS_{}.csv'

PROPERTIES_HEADER = ['OBJECT_TYPE', 'OBJECT_ID',
                'NAME', 'TYPE', 'DESCRIPTION', 'VALUE']
PROPERTIES_FILE = 'PROPERTIES_{}.csv'

COLLECTION_LINKAGES_HEADER = ['OBJECT_TYPE', 'OBJECT_ID',
                'COLLECTION_ID', 'COLLECTION_INSTANCE_NAME']
COLLECTION_LINKAGES_FILE = 'COLLECTION_LINKAGES_{}.csv'

def convert_str_dt(ts_original, ts_format):
    return datetime.strptime(ts_original, ts_format).strftime('%Y-%m-%d %H:%M:%S.%f')


def convert_dt(ts_original):
    return ts_original.strftime('%Y-%m-%d %H:%M:%S.%f')

class InterfaceContract(object):
    _header = []

    def __init__(self, file_date, file_name, filepath='.', compress=False, delta=False):
        self._data = []
        self._file_date = file_date
        self._filepath = filepath
        self._compress = compress
        if delta: # Append Delta if it is a Delta
            file_name = f'DELTA_{file_name}'
        self._file_name = f'{file_name}.gz' if self._compress else file_name
        self.file_name_path = os.path.join(filepath, self._file_name)
        self.open_file = gzip.open(self.file_name_path, 'wt', **FILE_SETTINGS) if self._compress else open(self.file_name_path, 'wt', **FILE_SETTINGS)
        self.open_file_writer = csv.writer(self.open_file, **FILE_FORMAT)
        self.open_file_writer.writerow(self._header)
        self.record_counter = 0


    def _validate(self, data):
        return True

    def _format(self, data):
        # TODO add generic formatting here. See clean_field_value()
        return data

    def close_file(self):
        logger.info('Finalising the {} file'.format(self.__class__.__name__))
        self.open_file.close()

    def close_and_remove(self):
        self.open_file.close()
        os.remove(self.file_name_path)

    def add(self, data):
        if self._validate(data):
            data = ['' if el is None else el.strip() if isinstance(el,str) else el for el in data]
            self.open_file_writer.writerow(self._format(data))
            self.record_counter += 1
        else:
            print('WARNING: Invalid data skipping')

    def execute_write_close(self, cur, query):
        self.execute_write(cur, query)
        self.close_file()
    
    def execute_write(self, cur, query):
        logger.info('Running queries to add to the {} file'.format(self.__class__.__name__))
        cur.execute(query)
        for row in cur:
            self.add(*['' if v is None else v.strip() if isinstance(v,str) else v for v in row]) # Replace Nones, strip wide columns

class Users(InterfaceContract):
    _header = USER_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = USERS_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, username, first_name='', last_name='', email='', is_system='', user_id=''):
        data = [username, first_name, last_name, email, is_system, user_id]
        super().add(data)

class Meta(InterfaceContract):
    _header = META_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = META_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, object_type, object_id, tool_object_type='', name='', description='', url='', path='', query_code='', created_at='', updated_at='', last_run_at=''):
        data = [object_type, object_id, tool_object_type, name, description,
                url, path, query_code, created_at, updated_at, last_run_at]
        super().add(data)

class Events(InterfaceContract):
    _header = EVENT_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = EVENT_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class Links(InterfaceContract):
    _header = LINK_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = LINK_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class DatabaseMetadata(InterfaceContract):
    _header = METADATA_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = METADATA_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class DatabaseLog(InterfaceContract):
    _header = DATABASELOG_HEADER
    _file_rollover_size_bytes = 314572800 # Bytes, 300MB

    def __init__(self, file_date, **kwargs):
        self._file_part = 1
        self._row_no_idx = DATABASELOG_HEADER.index('SQL_ROW_NO')
        file_name = DATABASELOG_FILE.format(str(self._file_part).zfill(3), file_date) # Part One File, multi part if it reaches size limit
        super().__init__(file_date, file_name, **kwargs)
        self.part_files = {} # Records any rolled files

    def add(self, *_header):
        data = [*_header]
        current_row_no = data[self._row_no_idx] # Set the previous row no
        if int(current_row_no) == 1: # If the SQL Row number is 1 then its a new SQL statement, valid to check for roll over first, this column is mandatory
            self.roll_file_check()
        super().add(data)

    def roll_file_check(self):
        """
        Checks if the file has reached the size limit to roll the file, only applies to DB Logs right now
        """
        file_info = os.stat(self.file_name_path)
        if file_info.st_size > self._file_rollover_size_bytes: # Roll over the filesize
            self.close_file() # Close file before opening new one
            self.part_files[self.file_name_path] = self.record_counter # Record the file and the record count then reset the record counter to 0 to maintain correct counts
            self.record_counter = 0
            self._file_part += 1
            file_name = DATABASELOG_FILE.format(str(self._file_part).zfill(3), self._file_date)
            self._file_name = f'{file_name}.gz' if self._compress else file_name
            self.file_name_path = os.path.join(self._filepath, self._file_name)
            self.open_file = gzip.open(self.file_name_path, 'wt', **FILE_SETTINGS) if self._compress else open(self.file_name_path, 'wt', **FILE_SETTINGS)
            self.open_file_writer = csv.writer(self.open_file, **FILE_FORMAT)
            self.open_file_writer.writerow(self._header)

class DatabaseDdl(InterfaceContract):
    _header = DDL_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = DDL_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class DatabaseDdlMetadata(InterfaceContract):
    _header = DDL_METADATA_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = DDL_METADATA_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class DatabaseMetadataKeys(InterfaceContract):
    _header = METADATA_KEYS_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = METADATA_KEYS_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class Role(InterfaceContract):
    _header = DATABASE_ROLE_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = DATABASE_ROLE_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class Properties(InterfaceContract):
    _header = PROPERTIES_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = PROPERTIES_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class CollectionLinkages(InterfaceContract):
    _header = COLLECTION_LINKAGES_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = COLLECTION_LINKAGES_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, *_header):
        data = [*_header]
        super().add(data)

class IDPUsers(InterfaceContract):
    _header = IDP_USER_HEADER

    def __init__(self, file_date, **kwargs):
        file_name = IDP_USERS_FILE.format(file_date)
        super().__init__(file_date, file_name, **kwargs)

    def add(self, username, first_name='', last_name='', email='', description='', is_system_user='', \
                is_login_user='', roles='', group_name='',  user_id=''):
        data = [username, first_name, last_name, email, description, is_system_user, is_login_user, roles, group_name, user_id]
        super().add(data)