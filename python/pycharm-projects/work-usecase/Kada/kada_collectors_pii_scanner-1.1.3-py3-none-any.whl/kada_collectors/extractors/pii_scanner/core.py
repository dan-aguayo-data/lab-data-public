import os
import traceback
import shutil
import logging
import multiprocessing
import json
from importlib import import_module
from datetime import datetime
from ..models import KTypes, KProps, CollectionLinkages, Properties
from .database_api import DatabaseConnectionType, SnowflakeAPI, RedshiftAPI, OracleAPI
from .detectors import DatabaseDatumDetectors, DEFAULT_DETECTORS, DETECTOR_REGISTRY

logger = logging.getLogger(__name__)

class SourceTypes():
    SNOWFLAKE = 'SNOWFLAKE'
    REDSHIFT = 'REDSHIFT'
    ORACLE = 'ORACLE'

SUPPORTED_SOURCE_TYPES = [k for k in SourceTypes.__dict__.keys() if not k.startswith('_')]
SUPPORTED_OBJECT_TYPES = [
    KTypes.TABLE
]
COLLECTION_ID = '3dbf7c4f-1d05-3b75-9920-9122e6eaed56' # Hardcoded UUID for the PII Collection related to Data
VALID_DEFAULT_DETECTORS = [ # User friendly name for easier inputs
    'Email',
    'AUPhoneNumber',
    'CreditCard',
    'AUTaxFileNumber',
    'AUZipCode',
    'AUDriversLicense',
    'AUBSBNumber',
    'AUBankAccountNumber',
    'AUMedicare',
    'AUPassport',
    'AUAddress'
]

class PIIScannerException(Exception):
    pass

class PIIScanner():
    _ver = '1.1.3'

    def __init__(self, source_type: str, rows: int, concurrency: int, object_list: list, pii_output_path: str, *args, default_detectors: list=[], delta: bool=False, **kwargs):
        """
        PII Scanner is designed to instantiate a scanner per target object
        source_type: What kind of source will the scanner be pointing to
        rows: How many rows are we sampling? 0 means all rows will be sampled
        concurrency: Should the Scanner be running in parallel, 0 means single thread
        object_list: 2D array in the form of a list of OBJECT_TYPE and OBJECT_ID,
        default_detectors: list of default detectors to run
            VALID_DEFAULT_DETECTORS
            If this is empty no defaults will run
        delta: Will this produce a partial file and not a full file?
        pii_output_path: The path to the output folder
        """
        self.source_type = source_type.upper().strip() # Give some leeway for typo errors
        self.rows = rows
        self.delta = delta
        self.concurrency = concurrency
        self.object_list = object_list
        self.output_path = pii_output_path
        self.compress = kwargs.get('compress', True) # All extractor configs should have a compress value, default to true
        self.default_detectors = default_detectors
        self.validate()
        self.collection_id = COLLECTION_ID
        self._data_collections_linkage = {} # Scanner results to be stored, this will be in the form OBJECT_TYPE, OBJECT_ID, COLLECTION_ID, COLLECTION_INSTANCE_NAME
        self._data_properties = {}
        self.register_default_detectors() # Remove and any default detectors if needed
        registry_print_out = {k.__name__: ', '.join(list(v.keys())) for k,v in DETECTOR_REGISTRY.items()}
        self.registered_detectors = DETECTOR_REGISTRY # Store the state of the registry local to the class
        logger.info(
            f"""
            =====
            Utilising scanner ver {self._ver} with the following parameters
                source_type = {self.source_type}
                rows = {self.rows}
                concurrency = {self.concurrency}
                collection_id = {self.collection_id}
                default_detectors = {self.default_detectors}
                delta = {self.delta}
                registered_detectors = {registry_print_out}
            =====
            """
        )
        self.extractor = None # Stores the Extractor class
        self.dbapi = None # Stores the API class
        self.load_extractor(*args, **kwargs)
        self.scan_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

    @staticmethod
    def divide_chunks(l, n):
        for i in range(0, len(l), n):
            yield l[i:i + n]

    def register_default_detectors(self):
        """
        Disables the default detectors thats not included in self.default_detectors
        """
        if self.default_detectors:
            lookup_set = set([f'{d}KadaDetector'.lower() for d in self.default_detectors]) # Make it case insensitive
            for cls_name in DEFAULT_DETECTORS:
                if cls_name.lower() not in lookup_set:
                    del DETECTOR_REGISTRY[DatabaseDatumDetectors][cls_name]

    def validate(self):
        """
        This validates all inputs before we go off on assumptions
        """
        logger.info('PIIScanner.validate: Validating scanner inputs.')
        if self.concurrency < 1:
            raise PIIScannerException(f'{self.concurrency} should be a value greater than or equal to 1 where 1 means no concurrency.')
        if self.source_type not in SUPPORTED_SOURCE_TYPES:
            supported_list = ','.join(SUPPORTED_SOURCE_TYPES)
            raise PIIScannerException(f'{self.source_type} is currently not supported, should be one of {supported_list}.')
        for obj in self.object_list:
            # Idx 0 is type
            # Idx 1 is the id
            supported_obj_list = ','.join(SUPPORTED_OBJECT_TYPES)
            if obj[0] not in SUPPORTED_OBJECT_TYPES:
                raise PIIScannerException(f'{obj[0]} with id {obj[1]} is currently not supported, should be one of {supported_obj_list}, please check the objects passed.')
        if self.rows < 0:
            raise PIIScannerException(f'Rows must be a value greater or equal to 0 where 0 means scan all rows, not {self.rows}')
        if self.concurrency > 1: # Set it up for multi processing
            chunk_size = int(len(self.object_list)/self.concurrency)
            if chunk_size == 0: # Can't ahve chunk of 0
                chunk_size = len(self.object_list)
            self.object_list = list(self.divide_chunks(self.object_list, chunk_size))
        else:
            self.object_list = [self.object_list]

    def load_extractor(self, *args, **kwargs):
        """
        Loads the correct extractor class and raises exception with a friendly message when not found.
        """
        try:
            logger.info('PIIScanner.load_extractor: Loading extractor class and testing connectivity.')
            extractor_mod = import_module(f'kada_collectors.extractors.{self.source_type.lower()}')
            self.extractor = extractor_mod.Extractor(*args, **kwargs)
            self.extractor.test_connection() # Make sure we can connect
            if self.source_type == SourceTypes.SNOWFLAKE:
                self.dbapi = SnowflakeAPI()
            elif self.source_type == SourceTypes.REDSHIFT:
                self.dbapi = RedshiftAPI()
            elif self.source_type == SourceTypes.ORACLE:
                self.dbapi = OracleAPI()
        except ImportError:
            raise PIIScannerException(f'Could not find the correct kada_collectors extractor library, ensure you have the extractor installed for {self.source_type} and try running again.')
        except Exception as exp:
            raise PIIScannerException(exp)
        
    def scan_con(self, con, obj, payloads):
        with con.cursor() as cur:
            sql = self.dbapi.get_select_query(obj[0], obj[1], self.rows)
            cur.execute(sql)
            column_list = [desc[0].decode('utf-8').replace('.','_') if isinstance(desc[0], bytes) else desc[0].replace('.','_') for desc in cur.description] # Use the DBAPI cursor description to get column list of names to indexes, handle byte return if it does
            table_key = obj[1].lower() # Place an entry for the table as well
            payloads[table_key] = { 
                'object_type': KTypes.TABLE,
                'collections': {},
                'rows': 0
            }
            column_key = None
            for row in cur:
                idx = 0
                for datum in row:
                    column_name = column_list[idx]
                    column_key = f'{obj[1]}.{column_name}'.lower()
                    payloads.setdefault(
                        column_key,
                        {
                            'object_type': KTypes.COLUMN,
                            'collections': {},
                            'rows': 0
                        }
                    )['rows'] += 1
                    for detector in self.registered_detectors[DatabaseDatumDetectors].values():
                        try:
                            pii_types = detector.detect(datum, column_name)
                        except Exception:
                            logger.warning(f'PIIScanner.scan_con: One of the dectectors caused an exception, skipping this detector\n{traceback.format_exc()}')
                            continue
                        if pii_types:
                            for pii_type in pii_types:
                                payloads[column_key]['collections'].setdefault(self.collection_id, {}).setdefault(pii_type.name, 0)
                                payloads[column_key]['collections'][self.collection_id][pii_type.name] += 1
                                payloads[table_key]['collections'].setdefault(self.collection_id, {}).setdefault(pii_type.name, 0)
                                payloads[table_key]['collections'][self.collection_id][pii_type.name] += 1
                    idx+=1
            if column_key:
                payloads[table_key]['rows'] = payloads[column_key]['rows'] # Take the last value and assign to table since its all the same

    def scan_data(self, obj_sets:list):
        """
        obj_sets is a chunk of records in the object list in the form [OBJECT_TYPE, OBJECT_ID]
        scans the actual stored data in the object at a sample rate defined by self.row
        """
        # Support Table Level objects only
        # Memory efficent structure per job
        # {
        #     object_id: {
        #         rows:,
        #         object_type:,
        #         collections: {
        #             collection_id: {
        #                 collection_instance_name: count
        #             }
        #         }
        #     }
        # }
        # We need to cater for two types of databases, databases tht can query across databases with a single connection and those that cant.
        payloads = {}
        if self.dbapi.database_connecton_type == DatabaseConnectionType.HOST:
            with self.extractor.get_connection() as con:# Don't share connections, so establish your own, reduce db connection time by processing in sub chunks
                total = len(obj_sets)
                num = 0
                for obj in obj_sets:
                    num+=1
                    try:
                        self.scan_con(con, obj, payloads)
                        logger.info('   {}/{} DONE {}'.format(num, total, ' '.join(obj)))
                    except Exception as exp:
                        logger.warning('    {}/{} FAILED {} - Skipping as SQL could not execute due to\n {}'.format(num, total, ' '.join(obj), str(exp)))
                        continue
        elif self.dbapi.database_connecton_type == DatabaseConnectionType.DATABASE: # Manually handle connection switching
            total = len(obj_sets)
            num = 0
            current_database = ''
            prev_database = ''
            con = None
            for obj in obj_sets:
                num+=1
                try:
                    current_database = self.dbapi.get_database(obj[0], obj[1])
                    if not con or current_database != prev_database: # Dynamically change the connection if database changes
                        if con:
                            con.close() # Close the previous connection first
                        con = self.extractor.get_connection(database=current_database)
                        prev_database = current_database # Record the previous database
                    self.scan_con(con, obj, payloads)
                    logger.info('   {}/{} DONE {}'.format(num, total, ' '.join(obj)))
                except Exception as exp:
                    logger.warning('    {}/{} FAILED {} - Skipping as SQL could not execute due to: {}'.format(num, total, ' '.join(obj), str(exp)))
                    continue
            if con:
                con.close() # Manually handle the close since we are not in a with block
        return payloads

    def scan_call_back(self, payloads: dict):
        """
        Pass in a payload which is a dict by scan_data in the form
        {
            object_id: {
                rows:,
                object_type:,
                collections: {
                    collection_id: {
                        collection_instance_name: count
                    }
                }
            }
        }
        Collapses into the right formats for the right data to be produced
        """
        for k,v in payloads.items():
            for c, cis in v.get('collections', {}).items():
                scan_stats = {}
                total_rows = v['rows'] # Should never be 0 if there was a result, so don't need to handle / 0 , if it errors on this something is wrong
                for ci, count in cis.items():
                    _key = v['object_type'] + f'{k}{c}{ci}'
                    self._data_collections_linkage.setdefault(_key, [v['object_type'], k, c, ci])
                    scan_stats[ci] = count
                if not total_rows and scan_stats: # How can we have stats if rows is 0:
                    raise PIIScannerException(f'PIIScanner.scan_call_back: Computed stats say there was 0 rows scanned for {k}, but somehow a PII result is attached, please check your detector.')
                else: # Transform the stats into percentage
                    for sck, scv in scan_stats.items():
                        scan_stats[sck] = '{:.2f}'.format(round((scv/total_rows) * 100.00, 2))
                _id_key = v['object_type'] + k
                if v['object_type'] == KTypes.COLUMN:
                    self._data_properties.setdefault(
                        _id_key + 'kada_pii_scanner_results_percentage_matched',
                        [v['object_type'], k, 'kada_pii_scanner_results_percentage_matched', KProps.JSON, 'Stats for the scan.', json.dumps(scan_stats)] # Dump it to ensure it uses " in the string representation
                    )
                self._data_properties.setdefault(
                    _id_key + 'kada_pii_scanner_data_scanned',
                    [v['object_type'], k, 'kada_pii_scanner_data_scanned', KProps.STRING, 'Timestamp in UTC when the the scan was performed.', self.scan_time]
                )
                self._data_properties.setdefault(
                    _id_key + 'kada_pii_scanner_rows_scanned',
                    [v['object_type'], k, 'kada_pii_scanner_rows_scanned', KProps.INTEGER, 'Count of rows scanned.', total_rows]
                )

    def produce_extract(self):
        date_suffix = datetime.now().strftime('%Y%m%d%H%M%S')
        if os.path.exists(self.output_path):
            shutil.rmtree(self.output_path)
        os.makedirs(self.output_path, exist_ok=True)

        col_linkage = CollectionLinkages(date_suffix, filepath=self.output_path, compress=self.compress, delta=self.delta)
        properties = Properties(date_suffix, filepath=self.output_path, compress=self.compress)
        [col_linkage.add(*r) for r in self._data_collections_linkage.values()]
        [properties.add(*r) for r in self._data_properties.values()]
        col_linkage.close_file()
        properties.close_file()

        return {
            col_linkage.file_name_path: col_linkage.record_counter,
            properties.file_name_path:  properties.record_counter
        }

    def scan(self):
        """
        Starts the scanning process
        Stores a linkage data inside _data_collections_linkage
        """
        logger.info('PIIScanner.scan: Commencing Scan.')
        if self.concurrency > 1: # Add a caluse to not initiate a worker spawn
            pool = multiprocessing.Pool(self.concurrency)
            processes = []
            for obj_sets in self.object_list:
                p = pool.apply_async(self.scan_data, args=(obj_sets,), callback=self.scan_call_back)
                processes.append(p)
            pool.close()
            pool.join()
            [logger.debug(p.get()) for p in processes] # Allow debug to fetch the errors that would otherwise be hidden
        else:
            [self.scan_call_back(self.scan_data(obj_sets)) for obj_sets in self.object_list]
        logger.info('PIIScanner.scan: Scanning complete')
        return self.produce_extract()