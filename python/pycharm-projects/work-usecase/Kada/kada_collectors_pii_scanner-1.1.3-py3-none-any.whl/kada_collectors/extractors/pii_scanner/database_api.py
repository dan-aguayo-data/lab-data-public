# #####
# Different sources may have different ways of creating SQL
# These classes aim to provide an easy method to change the SQL generated per source
# #####
import logging
from abc import ABC, abstractmethod
from ..models import KTypes

logger = logging.getLogger(__name__)

class DatabaseConnectionType():
    """
    Some database have connections at the database level and cannot change to another database without establishing a new connection, others
    can connect to the host level and switch database at will, this is all dependent also on how K treats the database, e.g. Oracle technically is a per
    database/instance connection but we treat each instance as a source, so this is classified as a HOST level
    """
    HOST = 'HOST'
    DATABASE = 'DATABASE'

class DatabaseAPI(ABC):
    database_connecton_type = None # Should be a DatabaseConnectionType value

    @abstractmethod
    def get_select_query(self, object_type: str, object_id: str, rows: int):
        """
        object_type: Object type we are scanning
        object_id: Object we are scanning
        """

    @abstractmethod
    def get_metadata_query(self, object_type: str, object_id: str):
        """
        object_type: Object type we are scanning
        object_id: Object we are scanning
        This gets the metadata related to the object
        Currently this is just the name of Columns if object_type is a Table,
        if the object_type is anything else then it will just be the name of the object itself
        """
    
class SnowflakeAPI(DatabaseAPI):
    database_connecton_type = DatabaseConnectionType.HOST

    def get_select_query(self, object_type: str, object_id: str, rows: int):
        if object_type == KTypes.TABLE:
            table_parts = object_id.lower().split('.')
            base_query = f'SELECT * FROM {table_parts[1]}.{table_parts[2]}.{table_parts[3]}'
            if rows:
                return f'{base_query} LIMIT {rows}'
            else:
                return base_query
        else:
            raise Exception(f'Unsupported object type {object_type}')

    def get_metadata_query(self, object_type: str, object_id: str):
        if object_type == KTypes.TABLE:
            table_parts = object_id.split('.') # This is a faster way to get the table column names where we use the cursor description https://peps.python.org/pep-0249/
            return f'SELECT * FROM {table_parts[1]}.{table_parts[2]}.{table_parts[3]} WHERE 1=2'
        else:
            raise Exception(f'Unsupported object type {object_type}')

class OracleAPI(DatabaseAPI):
    database_connecton_type = DatabaseConnectionType.HOST

    def get_select_query(self, object_type: str, object_id: str, rows: int):
        if object_type == KTypes.TABLE:
            table_parts = object_id.lower().split('.')
            base_query = f'SELECT * FROM {table_parts[2]}.{table_parts[3]}'
            if rows:
                return f'{base_query} WHERE ROWNUM <= {rows}' # Oracle uses WHERE ROWNUM instead of LIMIT
            else:
                return f'{base_query}'
        else:
            raise Exception(f'Unsupported object type {object_type}')

    def get_metadata_query(self, object_type: str, object_id: str):
        if object_type == KTypes.TABLE:
            table_parts = object_id.split('.') # This is a faster way to get the table column names where we use the cursor description https://peps.python.org/pep-0249/
            return f'SELECT * FROM {table_parts[2]}.{table_parts[3]} WHERE 1=2'
        else:
            raise Exception(f'Unsupported object type {object_type}')
        
class RedshiftAPI(DatabaseAPI):
    database_connecton_type = DatabaseConnectionType.DATABASE

    def get_database(self, object_type: str, object_id: str):
        if object_type == KTypes.TABLE:
            table_parts = object_id.lower().split('.')
            return table_parts[1]
        else:
            raise Exception(f'Unsupported object type {object_type}')
        
    def get_select_query(self, object_type: str, object_id: str, rows: int):
        if object_type == KTypes.TABLE:
            table_parts = object_id.lower().split('.')
            base_query = f'SELECT * FROM {table_parts[2]}.{table_parts[3]}'
            if rows:
                return f'{base_query} LIMIT {rows}'
            else:
                return base_query
        else:
            raise Exception(f'Unsupported object type {object_type}')

    def get_metadata_query(self, object_type: str, object_id: str):
        if object_type == KTypes.TABLE:
            table_parts = object_id.split('.') # This is a faster way to get the table column names where we use the cursor description https://peps.python.org/pep-0249/
            return f'SELECT * FROM {table_parts[2]}.{table_parts[3]} WHERE 1=2'
        else:
            raise Exception(f'Unsupported object type {object_type}')