# ###
# For the purpose of classifying PII Types and allowing the user to extend PIITypes
# ###

from abc import ABC

class PIIType(ABC):
    """
    Inhertied class for declaring a PIIType, if you define your own PIIType to produce in the Detectors it must inherit this class to be a valid PIIType
    use the validate_pii_type method to ensure it is a valid declaration

    Note that the name of the PIIType will show up as a the Collection Instance name inside K, 
    likewise if you have created types already in K, match the name of the instance in K with the class.name value attrib here.
    K will ignore the case and match based on a case insensitive match
    """
    name = 'PII Type Name'

def validate_pii_type(cls: PIIType):
    if not issubclass(cls, PIIType):
        raise Exception(f'{cls.__name__} does not inherit PIIType')
    if not getattr(cls, 'name'):
        raise Exception(f'{cls.__name__} does not have a name attribute')

# ###
# Out of the box PII Types 
# ###
class AUAddress(PIIType):
    name = 'AU Address'

class Email(PIIType):
    name = 'Email'
    
class AUPhoneNumber(PIIType):
    name = 'AU Phone Number'

class AUZipCode(PIIType):
    name = 'AU ZIP Code'

class CreditCard(PIIType):
    name = 'Credit Card'

class AUTaxFileNumber(PIIType):
    name = 'AU Tax File Number'

class AUDriversLicense(PIIType):
    name = 'AU Drivers License'

class AUMedicare(PIIType):
    name = 'AU Medicare'

class AUBankAccountNumber(PIIType):
    name = 'AU Bank Account Number'

class AUBSBNumber(PIIType):
    name = 'AU BSB Number'

class AUPassport(PIIType):
    name = 'AU Passport'

class Person(PIIType):
    name = 'Person'