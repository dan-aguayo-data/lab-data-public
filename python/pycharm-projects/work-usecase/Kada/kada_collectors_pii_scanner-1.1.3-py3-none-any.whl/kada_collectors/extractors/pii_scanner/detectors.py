# ###
# Datum Detectors : Operates at the data level
# Metadata Detectors : Operates at the metadata level i.e column names/table names
# ###

import inspect
import re
from datetime import datetime, date, time
from abc import ABC, abstractmethod
from .pii_types import AUAddress, \
    Email, \
    AUPhoneNumber, \
    CreditCard, \
    AUTaxFileNumber, \
    AUZipCode, \
    AUDriversLicense, \
    AUBSBNumber, \
    AUBankAccountNumber, \
    AUMedicare, \
    AUPassport

WHITESPACE_REGEX = re.compile(r'\s+', re.MULTILINE)
NEWLINE_REGEX = re.compile(r'\n+', re.MULTILINE)

class Detectors(ABC):
    """
    Base class for detectors
    """
    pass

class DatabaseDatumDetectors(Detectors):
    """
    Inherit this class for all Datum types
    """
    @abstractmethod
    def detect(self, datum: str, column_name: str):
        """
        datum: is the data that needs to checked, its up to the detector implimentation to transform the incoming dbapi value type and skip if required
        column_name: is the name of the column of which the data belongs to

        returns: A list of PIIType Instances that are matched
        """

DETECTOR_REGISTRY = { # Registery broken down by parent classes to allow differentiation between Metadata only vs Datum only
    DatabaseDatumDetectors: {}
}

class DetectorRegisterException(Exception):
    pass

def register_detector(detector: DatabaseDatumDetectors):
    """
    After you create a new class that inherits DatabaseDatumDetectors you can call this ensure the scanner knows about your new detector
    from kada_collectors.extractors.pii_scanner import register_detector DatabaseDatumDetectors
    
    @register_detector
    class YourDetectorClass(DatabaseDatumDetectors):
        pass

    or

    register_detector(YourDetectorClass)
    """
    if not inspect.isclass(detector):
        raise ValueError("Detector should be a class, not an instance.")
    if not issubclass(detector, tuple(DETECTOR_REGISTRY.keys())):
        raise ValueError("Detector should be an inherited class of DatabaseDatumDetectors")
    
    # Basic test of the detector so it doesn't fall over
    det = detector()
    for _type in ['string' , b'byte_string', 1, 1.0, True, date(2000, 1, 1), datetime(2000, 1, 1, 1, 1, 1), time(1, 1, 1)]:
        try:
            det.detect(_type, 'test_name')
        except Exception as exp:
            raise DetectorRegisterException(f'Detector {detector.__name__} failed basic input test with an exception, check that the detect method handles input types correctly.')

    for cls in DETECTOR_REGISTRY.keys():
        if issubclass(detector, cls):
            DETECTOR_REGISTRY[cls][det.__class__.__name__] = det

    return detector

# ###
# Actual Detectors defined here, we start with a Default blanket one that operates on regex and other predefined ones
# ###

class RegexKadaDetector(DatabaseDatumDetectors):
    """
    Default out of the box detector applying standard regexes
    """
    _pii_type = None
    _regex = None

    def detect(self, datum, column_name):
        """
        datum: is the data that needs to checked, its up to the detector implimentation to transform the incoming dbapi value type and skip if required
        column_name: is the name of the column of which the data belongs to

        returns: A list of PIIType Instances that are matched
        """
        matches = []
        if type(datum) not in {bool, date, datetime}: # We only don't apply to boolean/date/datetime
            if re.search(self._regex, str(datum)): # Transform the datum element to a string value first before applying regex
                matches.append(self._pii_type())
        return matches
    
@register_detector
class EmailKadaDetector(RegexKadaDetector):
    _pii_type = Email
    _regex = re.compile(r"([a-z0-9!#$%&'*+\/=?^_`{|.}~-]+@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)", re.MULTILINE | re.IGNORECASE)

@register_detector
class AUAddressKadaDetector(RegexKadaDetector):
    _pii_type = AUAddress
    _regex = re.compile(r'\d{1,4} [\w\s]{1,20}(?:street|st|avenue|ave|road|rd|highway|hwy|square|sq|trail|trl|drive|dr|court|ct|park|parkway|pkwy|circle|cir|boulevard|blvd)\W?(?=\s|$)', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUZipCodeKadaDetector(RegexKadaDetector):
    _pii_type = AUZipCode
    _regex = re.compile(r'[\s^]((0[289][0-9]{2})|([1345689][0-9]{3})|(2[0-8][0-9]{2})|(290[0-9])|(291[0-4])|(7[0-4][0-9]{2})|(7[8-9][0-9]{2}))[\s$]', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUDriversLicenseKadaDetector(RegexKadaDetector):
    _pii_type = AUDriversLicense
    _regex = re.compile(r'\b(?<![._-])([a-z0-9]{2}\d{2}[a-z0-9]{5})(?![._-])\b|\b(?<![._-])([a-z]{1,2}\d{5,7})(?![._-])\b|\b(?<![._-])([0-9]{7,10})(?![._-])\b|\b(?<![._-])(\d{5,7}[a-z]{1,2})(?![._-])\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUBSBNumberKadaDetector(RegexKadaDetector):
    _pii_type = AUBSBNumber
    _regex = re.compile(r'\b\s*\d{3}[- ]?\d{3}\s*\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUPassportKadaDetector(RegexKadaDetector):
    _pii_type = AUPassport
    _regex = re.compile(r'\b(^|\s)(N|E|D|F|A|C|U|X|PA|PB|PC|PD|PE|PF|PU|PW|PX|PZ)\d{7}($|\s)\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUBankAccountNumberKadaDetector(RegexKadaDetector):
    _pii_type = AUBankAccountNumber
    _regex = re.compile(r'\b(?!0\d[ -]?\d{8}|(?:\+61|0)[2-478](?:[ -]?\d){8})\d{3}-?\d{3}\s\d{6,10}\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUPhoneNumberKadaDetector(RegexKadaDetector):
    _pii_type = AUPhoneNumber
    _regex = re.compile(r'\b(?:\+?(61))? ?(?:\((?=.*\)))?(0?[2-57-8])\)? ?(\d\d(?:[- ](?=\d{3})|(?!\d\d[- ]?\d[- ]))\d\d[- ]?\d[- ]?\d{3})\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class AUMedicareKadaDetector(RegexKadaDetector):
    _pii_type = AUMedicare
    _regex = re.compile(r'\b[2-6]\d{2}(?:\s?\d{3}){2}\b', re.MULTILINE | re.IGNORECASE)

@register_detector
class CreditCardKadaDetector(DatabaseDatumDetectors):
    """
    Default out of the box detector for identifying credit card numbers https://www.regular-expressions.info/creditcard.html
    """
    _whitespace_regex = WHITESPACE_REGEX
    _newline_regex = NEWLINE_REGEX
    _numbers_regex = re.compile(r'[\-\+]*?[.0-9]+', re.MULTILINE) # Include +- and . for decimal
    _cc_regexes = {
        'visa': re.compile(r'^4[0-9]{12}(?:[0-9]{3})?$'),
        'mastercard': re.compile(r'^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$'),
        'amex': re.compile(r'^3[47][0-9]{13}$'),
        'diners': re.compile(r'^3(?:0[0-5]|[68][0-9])[0-9]{11}$'),
        'discover': re.compile(r'^6(?:011|5[0-9]{2})[0-9]{12}$'),
        'jcb': re.compile(r'^(?:2131|1800|35\d{3})\d{11}$')
    }

    def detect(self, datum, column_name):
        """
        datum: is the data that needs to checked, its up to the detector implimentation to transform the incoming dbapi value type and skip if required
        column_name: is the name of the column of which the data belongs to

        returns: A list of PIIType Instances that are matched
        """
        matches = []
        if type(datum) not in {bool, date, datetime}: # We only don't apply to boolean/date/datetime
            # We apply multiple stages when checking for credit card numbers
            # 1. Clean the string by stripping out spaces/- 
            datum = self._whitespace_regex.sub('', str(datum))
            datum = self._newline_regex.sub('', datum)
            # 2. Extract all 13-16 digit sets from the text for analysis
            for nums in self._numbers_regex.findall(datum):
                if not any(sym in nums for sym in ['+', '-', '.']): # These are clearly not CC numbers
                    if len(nums) >= 13 and len(nums) <= 16: # We don't include this in the regex to ensure we capture all consecutive digits and not partial of a consecutive set
                        # 3. Apply different analysis for different brands https://www.regular-expressions.info/creditcard.html
                        for reg in self._cc_regexes.values():
                            if re.match(reg, nums):
                                matches.append(CreditCard())
                                break # No need to continue
        return matches

@register_detector
class AUTaxFileNumberKadaDetector(DatabaseDatumDetectors):
    """
    Default out of the box detector for identifying TFN https://clearwater.com.au/code/tfn
    """
    _whitespace_regex = WHITESPACE_REGEX
    _newline_regex = NEWLINE_REGEX
    _numbers_regex = re.compile(r'[\-\+]*?[.0-9]+', re.MULTILINE) # Include +- and . for decimal
    _tfn_weights = [1, 4, 3, 7, 5, 8, 6, 9, 10]

    def detect(self, datum, column_name):
        """
        datum: is the data that needs to checked, its up to the detector implimentation to transform the incoming dbapi value type and skip if required
        column_name: is the name of the column of which the data belongs to

        returns: A list of PIIType Instances that are matched
        """
        matches = []
        if type(datum) not in {bool, date, datetime}: # We only don't apply to boolean/date/datetime
            # We apply multiple stages when checking for TFN numbers
            # 1. Clean the string by stripping out spaces/- 
            datum = self._whitespace_regex.sub('', str(datum))
            datum = self._newline_regex.sub('', datum)
            # 2. Extract all 9 digit sets from the text for analysis
            for nums in self._numbers_regex.findall(datum):
                if not any(sym in nums for sym in ['+', '-', '.']): # These are clearly not TFN numbers
                    if len(nums) == 9: # We don't include this in the regex to ensure we capture all consecutive digits and not partial of a consecutive set
                        # 3. Apply weighted sum
                        weighted_sum = sum([int(n) * self._tfn_weights[nums.index(nums)] for n in nums])
                        if weighted_sum % 11 == 0:
                            matches.append(AUTaxFileNumber())
                            break # No need to continue
        return matches

DEFAULT_DETECTORS = [
    AUAddressKadaDetector.__name__, 
    EmailKadaDetector.__name__, 
    AUZipCodeKadaDetector.__name__, 
    AUPhoneNumberKadaDetector.__name__, 
    CreditCardKadaDetector.__name__, 
    AUTaxFileNumberKadaDetector.__name__, 
    AUBankAccountNumberKadaDetector.__name__, 
    AUBSBNumberKadaDetector.__name__, 
    AUDriversLicenseKadaDetector.__name__, 
    AUPassportKadaDetector.__name__, 
    AUMedicareKadaDetector.__name__
]