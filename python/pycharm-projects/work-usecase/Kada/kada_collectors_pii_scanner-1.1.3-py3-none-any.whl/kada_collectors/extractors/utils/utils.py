import logging
import os
import sys
import pytz
import json
import hashlib
import re
from datetime import datetime
from shutil import copyfile
from ...extractors.models import KTypes

logger = logging.getLogger(__name__)

DEFAULT_HOST = 'unknown_host'
SEMI_COLON_DOUBLE_QUOTED_REGEX = re.compile(r'"[^"]*?;[^"]*?"')
SEMI_COLON_SINGLE_QUOTED_REGEX = re.compile(r"'[^']*?;[^']*?'")

def get_hwm(prefix, file_path: str=None):
    """
    prefix: The prefix for the _hwm.txt file
    file_path: Optional if the hwm if located else where, otherwise default is current execution directory
    """
    if file_path:
        filename = os.path.join(file_path, '{}_hwm.txt'.format(prefix))
    else:
        filename = './{}_hwm.txt'.format(prefix)
    try:
        with open(filename, 'r') as f:
            hwm = f.read().strip()
            hwm_start_dt = datetime.strptime(hwm, '%Y-%m-%d %H:%M:%S')
            return hwm_start_dt.strftime('%Y-%m-%d %H:%M:%S'), datetime.now(tz=pytz.timezone('UTC')).strftime('%Y-%m-%d %H:%M:%S')
    except Exception as exp:
        logger.info("No HWM file exists, so we'll start from 1900-01-01 00:00:00")
        hwm_start_dt = datetime.strptime('1900-01-01 00:00:00', '%Y-%m-%d %H:%M:%S')
        return hwm_start_dt.strftime('%Y-%m-%d %H:%M:%S'), datetime.now(tz=pytz.timezone('UTC')).strftime('%Y-%m-%d %H:%M:%S')

def publish_hwm(prefix, date, file_path: str=None):
    """
    prefix: The prefix for the _hwm.txt file
    date: is in str format %Y-%m-%d %H:%M:%S
    file_path: Optional if the hwm if located else where, otherwise default is current execution directory
    """
    if file_path:
        filename = os.path.join(file_path, '{}_hwm.txt'.format(prefix))
    else:
        filename = './{}_hwm.txt'.format(prefix)
    if os.path.isfile(filename):
        copyfile(filename, filename + '.prev'.format(prefix))
    with open(filename, 'w') as f:
        f.write(date)

def get_generic_logger(context='app'):
    context_logger = logging.getLogger() if context == 'root' else logging.getLogger(context)
    context_logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s.%(msecs)03d [%(process)d] [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
    handler.setFormatter(formatter)
    context_logger.addHandler(handler)
    return context_logger

def dry_run_mapping(input_path, meta_data, existing_mapping_dict={}):
    """
    Iterates through the meta and finds all the unique hosts, it'll merge the mapping.json if it exists in input
    """
    host_set = set([])
    for r in meta_data:
        if r[0] in [KTypes.DATABASE, KTypes.SCHEMA, KTypes.TABLE, KTypes.COLUMN]:
            if r[1]: # OBJECT_ID
                host = r[1].split('.')[0] # Worse case scenario it has no . but will not fail since its single index lists
                host_set.add(host.lower())
    new_mapping_dict = {**{k: '' for k in host_set}, **existing_mapping_dict}
    mapping_path = '{}/{}'.format(input_path, 'mapping.json')
    with open(mapping_path, 'w') as f:
        json.dump(new_mapping_dict, f)
    logger.info('Dry run was specified so producing a templated mapping file {}.'.format(mapping_path))

def load_config(config_file_path):
    """
    Loads the configuration json files
    """
    if os.path.isfile(config_file_path):
        logger.info('Loading {}.'.format(config_file_path))
        with open(config_file_path) as f:
            try:
                return json.load(f)
            except Exception:
                logger.error('Config file was an invalid JSON, please double check it.')
                sys.exit(1)
    else:
        logger.info('No config file was provided')
        return sys.exit(1)

def create_data_signature(_type, host=DEFAULT_HOST, database=None, schema=None, table=None, column=None, mapping={}):
    """
    Constructs a formated signture based on the type and returns it as output
    It will also automatically replace anything detected in the mapping
    _type: Is of KTypes
    host: host
    database: database
    schema: schema
    table: table
    column: column
    mapping: The standard mapping contract prescriped by K for tools
    """
    # Case insensitive search
    imapping = {k.lower(): v for k,v in mapping.items()}
    if host.lower() in imapping and host != DEFAULT_HOST: # Host mapping Scenario
        host = imapping[host.lower()]['host']
    elif database.lower() in imapping and host == DEFAULT_HOST: # DSN scenario
        host = imapping[database.lower()]['host']
        database = imapping[database.lower()]['database']
    host = host.replace('.', '_')
    database = database.replace('.', '_')
    if _type == KTypes.DATABASE:
        return '{}.{}'.format(host, database).lower()
    schema = schema.replace('.', '_')
    if _type == KTypes.SCHEMA:
        return '{}.{}.{}'.format(host, database, schema).lower()
    table = table.replace('.', '_')
    if _type == KTypes.TABLE:
        return '{}.{}.{}.{}'.format(host, database, schema, table).lower()
    column = column.replace('.', '_')
    if _type == KTypes.COLUMN:
        return '{}.{}.{}.{}.{}'.format(host, database, schema, table, column).lower()
    return NotImplementedError('{} is not supported in this method'.format(_type))

def chunks(lst, n):
    """
    Chunks a given list into small n sized lists
    """
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

def connection_key_val_to_dict(input):
    """
    Transforms input of a key=value; set into a dictionary where all keys are lower casedand white space stripped
    """
    # safetly cleanse the string of any quotes with ; as these would be irrelevant most likely
    input = SEMI_COLON_DOUBLE_QUOTED_REGEX.sub('""', input)
    input = SEMI_COLON_SINGLE_QUOTED_REGEX.sub("''", input)
    input = input.replace('\n', ';') # New lines should be replaced with semi colons
    _dict = dict(tuple(i.strip().split('=')) for i in [p for p in input.split(';') if p.strip()])
    return {k.strip().lower(): v.strip() for k,v in _dict.items()}

def generate_k_id(input):
    """
    Uses standard method of stripping and lowering and applying md5 to generate a hash as an ID
    This should be used if the source doesn't provide an ID of such
    """
    return hashlib.md5(input.strip().lower().encode()).hexdigest()

def format_iso_ts(input):
    '''
    Replaces the input .replace('T', ' ').replace('Z', '')
    '''
    if input: # Incase you pass in nothing, don't want it breaking
        return input.replace('T', ' ').replace('Z', '')
    else:
        return input
    
def exp_checker(_data_linkages, _data_meta):
    """
    BETA
    2022-11-04: Sidney Chen
    Experimental checker to compare linakge to meta data, potentially rolled out to other collectors if we standardise the output. 
    Might need to check the csv file instead.
    """
    for k,v in _data_linkages.items():
        src_key = f'{v[0]}{v[1]}'
        trg_key = f'{v[2]}{v[3]}'
        if src_key not in _data_meta and not src_key.startswith(KTypes.USER):
            logger.warning(f'exp_checker: Produced linkage source {src_key} not in meta for {v}.')
        if trg_key not in _data_meta and not trg_key.startswith(KTypes.USER):
            logger.warning(f'exp_checker: Produced linkage target {trg_key} not in meta for {v}.')
