import logging

logger = logging.getLogger(__name__)

class ExtractorException(Exception):
    pass

class BaseExtractor():
    def __init__(self, *args, **kwargs):
        self.sql = {} # Default blank, overwrite the method if the class uses something different

    def list_sql(self):
        """
        Lists the name of all available internal SQL scripts being used
        """
        return list(self.sql.keys())

    def get_sql(self, sql_name: str):
        """
        Gets the actual SQL statement by name
        """
        if sql_name not in self.sql:
            raise ExtractorException('{} is not a valid sql name, call list_sql to see list of valid names'.format(sql_name))
        else:
            return self.sql[sql_name]

    def overwrite_sql(self, sql_name: str, statement: str):
        """
        Replaces an actual SQL statement by name
        """
        if sql_name not in self.sql:
            raise ExtractorException('{} is not a valid sql name, call list_sql to see list of valid names'.format(sql_name))
        else:
            self.sql[sql_name] = statement

    def test_connection(self):
        """
        Purpose of testing the connection for a given extractor
        """
        raise NotImplementedError('Class has no test connection method, you may choose to impliment one.')

    def test_access(self):
        """
        Purpose of testing if the extractor and inputs given proivde access to all end points or database tables required to do the extraction
        """
        raise NotImplementedError('Class has no test access method, you may choose to impliment one, but note that this will be coming in the future.')

    def get_connection(self):
        """
        Purpose of returning the extractor connection
        """
        raise NotImplementedError('Most likely does not support returning a connection.')