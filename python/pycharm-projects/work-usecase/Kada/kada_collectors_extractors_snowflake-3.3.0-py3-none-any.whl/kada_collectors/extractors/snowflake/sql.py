DB_SQL = {
"DATABASE_LOGS_SQL": """
SELECT
COALESCE(DATABASE_NAME, 'UNKNOWN_DATABASE') AS DATABASENAME -- NEED EXTRACT BASED ON DB LEVEL
,START_TIME AS EXECUTION_TIME -- MANDATORY APPLY A TIMEZONE CONVERSION TO UTC IF REQUIRED
,QUERY_ID AS QUERY_ID -- MANDATORY
,USER_NAME AS USERNAME -- MANDATORY
,USER_NAME AS USER_ID -- MANDATORY
,SCHEMA_NAME AS SCHEMANAME -- MANDATORY
,NULL AS HOST_ID -- CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS APP_ID -- CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS CLIENT_ID -- CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS CLIENT_ADDRESS -- CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,QUERY_TEXT AS SQL_STATEMENT -- MANDATORY
,TOTAL_ELAPSED_TIME AS RUNTIME -- MANDATORY CAN BE BLANK
,ROWS_PRODUCED AS ROW_COUNT -- MANDATORY CAN BE BLANK
,SESSION_ID AS SESSION_ID -- MANDATORY CAN BE BLANK
,NULL AS SESSION_START_TIME -- MANDATORY CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS SESSION_SOURCE -- MANDATORY CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS PROXY_USERNAME -- MANDATORY CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,NULL AS PROXY_ROLE -- MANDATORY CURRENTLY CANNOT BE JOINED IN SNOWFLAKE LOGIN_HISTORY
,WAREHOUSE_ID AS COMPUTE_ID
,WAREHOUSE_NAME AS COMPUTE_NAME
,1 AS SQL_ROW_NO
FROM
account_usage.query_history
WHERE EXECUTION_STATUS = 'SUCCESS'
AND USERNAME <> 'SNOWFLAKE' -- EXCLUDE SNOWFLAKE USER UNLESS YOU WANT TO TRACK THIS SYSTEM USER
AND (
  LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'COMMIT%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'SHOW%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'DESC%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'USE%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'GRANT%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'ALTER%'
  AND LTRIM(UPPER(QUERY_TEXT)) NOT LIKE 'TRUNCATE%'
  AND NOT REGEXP_LIKE(LTRIM(UPPER(QUERY_TEXT)), '.*FROM\\\\s*?(@|''s3:\\\\/\\\\/|''azure:\\\\/\\\\/).*', 'i') -- CASE INSENSITIVE FILTER OUT FROM @ PATTERN
) -- ADD ADDITIONAL EXCLUSIONS DEPENDING ON ENVIRONMENT SYSTEM NOISE E.G. TRANSACTION CALLS ETC.
AND START_TIME::TIMESTAMP >= '{0}'::TIMESTAMP
AND START_TIME::TIMESTAMP < '{1}'::TIMESTAMP
ORDER BY SCHEMANAME, EXECUTION_TIME DESC
""",

"DDL_METADATA_SQL": """
SELECT
table_catalog AS DATABASENAME,
table_schema AS SCHEMANAME,
table_name AS OBJECT_NAME,
table_id AS OBJECT_VERSION,
'VIEW' AS OBJECT_TYPE,
table_owner AS CREATE_USERNAME,
created AS CREATE_TIMESTAMP,
NULL AS UPDATE_USERNAME,
last_altered AS UPDATE_TIMESTAMP,
NULL AS ACCESS_COUNT,
NULL AS LAST_ACCESS_TIMESTAMP
FROM account_usage.views t
WHERE table_schema != 'INFORMATION_SCHEMA'
AND UPPER(table_catalog) IN ('{0}')
AND deleted IS NULL
""",

"DDL_SQL": """
SELECT
table_catalog AS DATABASENAME,
'VIEW' AS OBJECT_TYPE,
table_schema AS SCHEMANAME,
table_name AS OBJECT_NAME,
view_definition AS OBJECT_DDL
FROM account_usage.views t
WHERE table_schema != 'INFORMATION_SCHEMA'
AND UPPER(table_catalog) IN ('{0}')
AND deleted IS NULL
""",

"LINKAGE_SQL": """
SHOW STREAMS IN ACCOUNT;
SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(table_catalog_name, '.', '_') || '.' || REPLACE(table_schema_name, '.', '_') || '.' || REPLACE(table_name, '.', '_')) AS "SRC_OBJECT_ID", -- Host to be formated by the Extractor
    'FILE' AS "TRG_OBJECT_TYPE",
    MD5(LOWER(
        REGEXP_SUBSTR(stage_location || file_name, '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/') ||
        REGEXP_REPLACE(
            REGEXP_REPLACE(
                REGEXP_REPLACE(
                    REPLACE(stage_location || file_name, REGEXP_SUBSTR(stage_location || file_name, '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/'), ''), 
                    '\\\\d{{4}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- T]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- \\\\.]{{0,1}}\\\\d{{0,9}}Z{{0,1}}', 
                    'X'
                ),
                '[a-fA-F0-9\\\\-\\\\_]{{8,}}', 
                'X'
            ), 
            '\\\\d', 
            'X'
        )
    )) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.copy_history
WHERE first_error_message IS NULL
AND status <> 'Load failed'
AND file_name IS NOT NULL
AND last_load_time::TIMESTAMP >= '{1}'::TIMESTAMP
AND last_load_time::TIMESTAMP < '{2}'::TIMESTAMP
AND REGEXP_LIKE(stage_location || file_name , '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/.*')

UNION ALL

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE("database_name", '.', '_') || '.' || REPLACE("schema_name", '.', '_') || '.' || REPLACE("name", '.', '_')) AS "SRC_OBJECT_ID", 
    'TABLE' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || "table_name") AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
WHERE "base_tables" != 'No privilege or table dropped'
AND "source_type" != 'Stage'
""",

"META_SQL": """
SHOW STREAMS IN ACCOUNT;
WITH CORE AS (
    SELECT
        REGEXP_SUBSTR(stage_location || file_name, '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/') ||
        REGEXP_REPLACE(
            REGEXP_REPLACE(
                REGEXP_REPLACE(
                    REPLACE(stage_location || file_name, REGEXP_SUBSTR(stage_location || file_name, '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/'), ''), 
                    '\\\\d{{4}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- T]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- \\\\.]{{0,1}}\\\\d{{0,9}}Z{{0,1}}', 
                    'X'
                ),
                '[a-fA-F0-9\\\\-\\\\_]{{8,}}', 
                'X'
            ), 
            '\\\\d', 
            'X'
        ) AS "PATH",
        CASE WHEN 
            REGEXP_REPLACE(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(
                        file_name, 
                        '\\\\d{{4}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- T]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- \\\\.]{{0,1}}\\\\d{{0,9}}Z{{0,1}}', 
                        'X'
                    ),
                    '[a-fA-F0-9\\\\-\\\\_]{{8,}}', 
                    'X'
                ), 
                '\\\\d', 
                'X'
            ) LIKE '%\\\\%' 
            THEN SPLIT_PART(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(
                        REGEXP_REPLACE(
                            file_name, 
                            '\\\\d{{4}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- T]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- \\\\.]{{0,1}}\\\\d{{0,9}}Z{{0,1}}',
                            'X'
                        ),
                        '[a-fA-F0-9\\\\-\\\\_]{{8,}}', 
                        'X'
                    ), 
                    '\\\\d', 
                    'X'
                ), 
                '\\\\', 
                -1
            ) 
            ELSE SPLIT_PART(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(
                        REGEXP_REPLACE(
                            file_name, 
                            '\\\\d{{4}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- ]\\\\d{{1,2}}[_\\\\- T]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- :]\\\\d{{1,2}}[_\\\\- \\\\.]{{0,1}}\\\\d{{0,9}}Z{{0,1}}', 
                            'X'
                        ),
                        '[a-fA-F0-9\\\\-\\\\_]{{8,}}', 
                        'X'
                    ), 
                    '\\\\d', 
                    'X'
                ), 
                '/', 
                -1
            ) END AS "NAME",
        last_load_time::TIMESTAMP AS "UPDATED_AT"
    FROM account_usage.copy_history
    WHERE first_error_message IS NULL
    AND status <> 'Load failed'
    AND file_name IS NOT NULL
    AND REGEXP_LIKE(stage_location || file_name , '^\\\\w+:\\\\/\\\\/[a-zA-Z0-9_.-]+\\\\/.*')
    AND last_load_time::TIMESTAMP >= '{0}'::TIMESTAMP
    AND last_load_time::TIMESTAMP < '{1}'::TIMESTAMP
)

SELECT
    'FILE' AS "OBJECT_TYPE",
    MD5(LOWER(CORE.PATH)) AS "OBJECT_ID",
    '' AS "TOOL_OBJECT_TYPE",
    CORE.NAME AS "NAME",
    '' AS "DESCRIPTION",
    '' AS "URL",
    CORE.PATH AS "PATH",
    '' AS "QUERY_CODE",
    '' AS "CREATED_AT",
    MAX(CORE.UPDATED_AT) AS "UPDATED_AT",
    MAX(CORE.UPDATED_AT) AS "LAST_RUN_AT"
FROM CORE
GROUP BY
    CORE.PATH,
    CORE.NAME
""",

"METADATA_KEYS_SQL": """
SHOW PRIMARY KEYS IN ACCOUNT;
SELECT
    "database_name" AS databasename,
    'TABLE' AS type,
    "schema_name" AS schemaname,
    "table_name" AS tablename,
    "column_name" AS columnname,
    'Y' AS primary_key_flag,
    '' AS foreign_key_target_databasename,
    '' AS foreign_key_target_tablename,
    '' AS foreign_key_target_columnname,
    '' AS partition_key_flag
FROM TABLE(result_scan(last_query_id()))
WHERE UPPER("database_name") IN ('{0}')
   ORDER BY "schema_name", "table_name"
""",

"METADATA_SQL": """
SHOW STREAMS IN ACCOUNT;
SELECT
t.table_catalog AS DATABASENAME,
CASE 
    WHEN t.table_type = 'BASE TABLE' THEN 'TABLE' 
    WHEN t.table_type IN ('MATERIALIZED VIEW', 'EXTERNAL TABLE', 'VIEW') THEN t.table_type
    ELSE 'TABLE'
END AS TYPE,
t.table_schema AS SCHEMANAME,
t.table_name AS TABLENAME,
c.column_name AS COLUMNNAME,
c.data_type ||
CASE WHEN c.character_maximum_length IS NOT NULL THEN '(' ||  c.character_maximum_length || ')'
WHEN c.numeric_precision IS NOT NULL THEN '(' ||  c.numeric_precision || ')'
ELSE '' END AS DATATYPE,
CASE WHEN is_nullable = 'YES'
THEN 'Y' ELSE 'N' END AS NULLABLE
FROM account_usage.tables t
INNER JOIN account_usage.columns c
ON t.table_schema = c.table_schema
AND t.table_name = c.table_name
AND t.table_catalog = c.table_catalog
WHERE t.table_schema != 'INFORMATION_SCHEMA'
AND c.table_schema != 'INFORMATION_SCHEMA'
AND t.deleted IS NULL
AND c.deleted IS NULL
AND UPPER(t.table_catalog) IN ('{0}')

UNION ALL

SELECT
str."database_name" AS DATABASENAME,
'STREAM' AS TYPE,
str."schema_name" AS SCHEMANAME,
str."name" AS TABLENAME,
c.column_name AS COLUMNNAME,
c.data_type ||
CASE WHEN c.character_maximum_length IS NOT NULL THEN '(' ||  c.character_maximum_length || ')'
WHEN c.numeric_precision IS NOT NULL THEN '(' ||  c.numeric_precision || ')'
ELSE '' END AS DATATYPE,
CASE WHEN is_nullable = 'YES'
THEN 'Y' ELSE 'N' END AS NULLABLE
FROM account_usage.tables t
INNER JOIN account_usage.columns c
ON t.table_schema = c.table_schema
AND t.table_name = c.table_name
AND t.table_catalog = c.table_catalog
INNER JOIN TABLE(RESULT_SCAN(LAST_QUERY_ID())) str
ON t.table_catalog || '.' || t.table_schema || '.' || t.table_name = str."table_name"
AND t.table_schema = str."schema_name"
AND t.table_catalog = str."database_name"
WHERE str."base_tables" != 'No privilege or table dropped'
AND t.deleted IS NULL
AND c.deleted IS NULL
AND UPPER(t.table_catalog) IN ('{0}')

UNION ALL

SELECT
str."database_name" AS DATABASENAME,
'STREAM' AS TYPE,
str."schema_name" AS SCHEMANAME,
str."name" AS TABLENAME,
c.column_name AS COLUMNNAME,
'' AS DATATYPE,
'N' AS NULLABLE
FROM account_usage.tables t
INNER JOIN (
    SELECT 'METADATA$ACTION' AS column_name
    UNION ALL
    SELECT 'METADATA$ISUPDATE' AS column_name
    UNION ALL
    SELECT 'METADATA$ROW_ID' AS column_name
) c
INNER JOIN TABLE(RESULT_SCAN(LAST_QUERY_ID())) str
ON t.table_catalog || '.' || t.table_schema || '.' || t.table_name = str."table_name"
AND t.table_schema = str."schema_name"
AND t.table_catalog = str."database_name"
WHERE str."base_tables" != 'No privilege or table dropped'
AND t.deleted IS NULL
AND UPPER(t.table_catalog) IN ('{0}')

ORDER BY TYPE,DATABASENAME,TABLENAME
""",

"PROPERTIES_SQL""": """
SHOW STREAMS IN ACCOUNT;
SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(table_catalog, '.', '_') || '.' || REPLACE(table_schema, '.', '_') || '.' || REPLACE(table_name, '.', '_')) AS OBJECT_ID,
'row_count' AS NAME,
'INTEGER' AS TYPE,
'Table row count - frequently refreshed tables may show 0 rows.' AS DESCRIPTION,
row_count::VARCHAR AS VALUE
FROM account_usage.tables
WHERE deleted IS NULL
AND UPPER(table_catalog) IN ('{1}')

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(table_catalog, '.', '_') || '.' || REPLACE(table_schema, '.', '_') || '.' || REPLACE(table_name, '.', '_')) AS OBJECT_ID,
'table_size (b)' AS NAME,
'INTEGER' AS TYPE,
'Table size in bytes - frequently refreshed tables may show 0 bytes.' AS DESCRIPTION,
bytes::VARCHAR AS VALUE
FROM account_usage.tables
WHERE deleted IS NULL
AND UPPER(table_catalog) IN ('{1}')

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(table_catalog, '.', '_') || '.' || REPLACE(table_schema, '.', '_') || '.' || REPLACE(table_name, '.', '_')) AS OBJECT_ID,
'last_altered' AS NAME,
'DATETIME' AS TYPE,
'When the table or view was last updated.' AS DESCRIPTION,
TO_CHAR(last_altered, 'YYYY-MM-DD HH24:MI:SS') AS VALUE
FROM account_usage.tables
WHERE deleted IS NULL
AND UPPER(table_catalog) IN ('{1}')

UNION ALL

SELECT
'SCHEMA' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(catalog_name, '.', '_') || '.' || REPLACE(schema_name, '.', '_')) AS OBJECT_ID,
'last_altered' AS NAME,
'DATETIME' AS TYPE,
'When the schema was last updated.' AS DESCRIPTION,
TO_CHAR(last_altered, 'YYYY-MM-DD HH24:MI:SS') AS VALUE
FROM account_usage.schemata
WHERE deleted IS NULL
AND UPPER(catalog_name) IN ('{1}')

UNION ALL

SELECT
'DATABASE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(database_name, '.', '_')) AS OBJECT_ID,
'last_altered' AS NAME,
'DATETIME' AS TYPE,
'When the database was last updated.' AS DESCRIPTION,
TO_CHAR(last_altered, 'YYYY-MM-DD HH24:MI:SS') AS VALUE
FROM account_usage.databases
WHERE deleted IS NULL
AND UPPER(database_name) IN ('{1}')

UNION ALL

SELECT
'DATABASE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(database_name, '.', '_')) AS OBJECT_ID,
'kada_prop_source_comment' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
comment AS VALUE
FROM account_usage.databases
WHERE deleted IS NULL
AND UPPER(database_name) IN ('{1}')
AND comment IS NOT NULL

UNION ALL

SELECT
'SCHEMA' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(catalog_name, '.', '_') || '.' || REPLACE(schema_name, '.', '_')) AS OBJECT_ID,
'kada_prop_source_comment' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
comment AS VALUE
FROM account_usage.schemata
WHERE deleted IS NULL
AND UPPER(catalog_name) IN ('{1}')
AND comment IS NOT NULL

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(table_catalog, '.', '_') || '.' || REPLACE(table_schema, '.', '_') || '.' || REPLACE(table_name, '.', '_')) AS OBJECT_ID,
'kada_prop_source_comment' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
comment AS VALUE
FROM account_usage.tables
WHERE deleted IS NULL
AND UPPER(table_catalog) IN ('{1}')
AND comment IS NOT NULL

UNION ALL

SELECT
'COLUMN' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(table_catalog, '.', '_') || '.' || REPLACE(table_schema, '.', '_') || '.' || REPLACE(table_name, '.', '_') || '.' || REPLACE(column_name, '.', '_')) AS OBJECT_ID,
'kada_prop_source_comment' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
comment AS VALUE
FROM account_usage.columns
WHERE deleted IS NULL
AND UPPER(table_catalog) IN ('{1}')
AND comment IS NOT NULL

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(c.table_catalog, '.', '_') || '.' || REPLACE(c.table_schema, '.', '_') || '.' || REPLACE(c.table_name, '.', '_')) AS OBJECT_ID,
'kada_prop_masked' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
LISTAGG(DISTINCT pr.policy_name, ' ') AS VALUE
FROM account_usage.columns c
LEFT JOIN account_usage.policy_references pr 
ON pr.ref_database_name = c.table_catalog
AND pr.ref_schema_name = c.table_schema
AND pr.ref_entity_name = c.table_name
AND pr.ref_column_name = c.column_name
AND pr.policy_status = 'ACTIVE'
AND pr.ref_column_name IS NOT NULL
AND UPPER(pr.ref_database_name) IN ('{1}')
WHERE c.table_schema != 'INFORMATION_SCHEMA'
AND c.deleted IS NULL
AND UPPER(c.table_catalog) IN ('{1}')
GROUP BY 
c.table_catalog,
c.table_schema,
c.table_name

UNION ALL

SELECT
'COLUMN' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE(c.table_catalog, '.', '_') || '.' || REPLACE(c.table_schema, '.', '_') || '.' || REPLACE(c.table_name, '.', '_') || '.' || REPLACE(c.column_name, '.', '_')) AS OBJECT_ID,
'kada_prop_masked' AS NAME,
'STRING' AS TYPE,
'Special KADA property.' AS DESCRIPTION,
LISTAGG(DISTINCT pr.policy_name, ' ') AS VALUE
FROM account_usage.columns c
LEFT JOIN account_usage.policy_references pr 
ON pr.ref_database_name = c.table_catalog
AND pr.ref_schema_name = c.table_schema
AND pr.ref_entity_name = c.table_name
AND pr.ref_column_name = c.column_name
AND pr.policy_status = 'ACTIVE'
AND pr.ref_column_name IS NOT NULL
AND UPPER(pr.ref_database_name) IN ('{1}')
WHERE c.table_schema != 'INFORMATION_SCHEMA'
AND c.deleted IS NULL
AND UPPER(c.table_catalog) IN ('{1}')
GROUP BY 
c.table_catalog,
c.table_schema,
c.table_name,
c.column_name

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE("database_name", '.', '_') || '.' || REPLACE("schema_name", '.', '_') || '.' || REPLACE("name", '.', '_')) AS OBJECT_ID,
'mode' AS NAME,
'STRING' AS TYPE,
'Displays APPEND_ONLY if the stream is an append-only stream. Displays INSERT_ONLY if the stream only returns information for inserted rows. Currently applies to streams on external tables only. For streams on tables, the column displays DEFAULT.' AS DESCRIPTION,
"mode" AS VALUE
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
WHERE "base_tables" != 'No privilege or table dropped'
AND "source_type" != 'Stage'

UNION ALL

SELECT
'TABLE' AS OBJECT_TYPE,
LOWER('{0}.' || REPLACE("database_name", '.', '_') || '.' || REPLACE("schema_name", '.', '_') || '.' || REPLACE("name", '.', '_')) AS OBJECT_ID,
'stale' AS NAME,
'STRING' AS TYPE,
'Indicates whether the stream was last read before the stale_after time (see below). If this is TRUE, the stream may be stale. When a stream is stale, it cannot be read. Recreate the stream to resume reading from it. To prevent a stream from becoming stale, consume the stream before stale_after.' AS DESCRIPTION,
"stale" AS VALUE
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
WHERE "base_tables" != 'No privilege or table dropped'
AND "source_type" != 'Stage'
""",

"ROLES_SQL": """
SELECT
'TABLE' AS "OBJECT_TYPE",
LOWER('{0}.' || TABLE_CATALOG || '.' || REPLACE(TABLE_SCHEMA, '.', '_') || '.' || REPLACE(NAME, '.', '_')) AS "OBJECT_ID",
'' AS "USER",
GRANTEE_NAME AS "ROLE"
FROM account_usage.grants_to_roles
WHERE TABLE_CATALOG IS NOT NULL
AND TABLE_SCHEMA IS NOT NULL
AND NAME IS NOT NULL
AND DELETED_ON IS NULL
AND GRANTED_ON IN ('TABLE', 'VIEW')

UNION

SELECT
'USER' AS "OBJECT_TYPE",
'' AS "OBJECT_ID",
GRANTEE_NAME AS "USER",
"ROLE" AS "ROLE"
FROM account_usage.grants_to_users
WHERE GRANTEE_NAME IS NOT NULL
AND DELETED_ON IS NULL

ORDER BY "ROLE" DESC
""",

"LINKAGE_EXT_SQL": """
WITH access_hist AS (
        SELECT
            objects_modified,
            object_modified_by_ddl,
            direct_objects_accessed,
            base_objects_accessed
        FROM
            snowflake.account_usage.access_history
        WHERE
            query_start_time::TIMESTAMP >= '{2}'::TIMESTAMP
            AND query_start_time::TIMESTAMP < '{3}'::TIMESTAMP
    ), direct_data AS (
    SELECT DISTINCT
        om.value: "objectId" AS target_table_id,
        columns_modified.value: "columnId" AS target_column_id,
        direct_sources.value: "columnName" as source_column_name,
        direct_sources.value: "objectId" as source_table_id
    FROM access_hist,
    LATERAL FLATTEN(
        input => access_hist.objects_modified
    ) om,
    LATERAL FLATTEN(
        input => om.value: "columns", 
        outer => true
    ) columns_modified,
    LATERAL FLATTEN(
        input => columns_modified.value: "directSources",
        outer => true
    ) direct_sources
    WHERE 
        UPPER(om.value: "objectDomain") IN ('EXTERNAL TABLE', 'MATERIALIZED VIEW', 'VIEW', 'STREAM', 'TABLE', 'BASE TABLE')
), base_data AS (
    SELECT DISTINCT
        om.value: "objectId" AS target_table_id,
        columns_modified.value: "columnId" AS target_column_id,
        direct_sources.value: "columnName" as source_column_name,
        direct_sources.value: "objectId" as source_table_id
    FROM access_hist,
    LATERAL FLATTEN(
        input => access_hist.objects_modified
    ) om,
    LATERAL FLATTEN(
        input => om.value: "columns", 
        outer => true
    ) columns_modified,
    LATERAL FLATTEN(
        input => columns_modified.value: "baseSources",
        outer => true
    ) direct_sources
    WHERE 
        UPPER(om.value: "objectDomain") IN ('EXTERNAL TABLE', 'MATERIALIZED VIEW', 'VIEW', 'STREAM', 'TABLE', 'BASE TABLE')
), ddl_data AS (
    SELECT DISTINCT
        access_hist.object_modified_by_ddl: "objectId" AS target_table_id,
        direct_columns.value: "columnId" as column_id
    FROM access_hist,
    LATERAL FLATTEN(
        input => access_hist.direct_objects_accessed
    ) direct_objects,
    LATERAL FLATTEN(
        input => direct_objects.value: "columns"
    ) direct_columns
    WHERE 
        UPPER(access_hist.object_modified_by_ddl: "objectDomain") IN ('EXTERNAL TABLE', 'MATERIALIZED VIEW', 'VIEW', 'STREAM', 'TABLE', 'BASE TABLE')
    UNION 
    SELECT DISTINCT
        access_hist.object_modified_by_ddl: "objectId" AS target_table_id,
        base_columns.value: "columnId" as column_id
    FROM access_hist,
    LATERAL FLATTEN(
        input => access_hist.base_objects_accessed
    ) base_objects,
    LATERAL FLATTEN(
        input => base_objects.value: "columns"
    ) base_columns
    WHERE 
        UPPER(access_hist.object_modified_by_ddl: "objectDomain") IN ('EXTERNAL TABLE', 'MATERIALIZED VIEW', 'VIEW', 'STREAM', 'TABLE', 'BASE TABLE')
)

SELECT DISTINCT
    'COLUMN' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_column.table_catalog, '.', '_') || '.' || REPLACE(target_column.table_schema, '.', '_') || '.' || REPLACE(target_column.table_name, '.', '_') || '.' || REPLACE(target_column.column_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'COLUMN' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_') || '.' || REPLACE(direct_data.source_column_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.columns target_column
INNER JOIN direct_data ON direct_data.target_column_id = target_column.column_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = direct_data.source_table_id
WHERE target_column.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND direct_data.target_column_id IS NOT NULL
AND UPPER(target_column.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION 

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'COLUMN' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_') || '.' || REPLACE(direct_data.source_column_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN direct_data ON direct_data.target_table_id = target_table.table_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = direct_data.source_table_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'TABLE' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN direct_data ON direct_data.target_table_id = target_table.table_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = direct_data.source_table_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION 

SELECT DISTINCT
    'COLUMN' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_column.table_catalog, '.', '_') || '.' || REPLACE(target_column.table_schema, '.', '_') || '.' || REPLACE(target_column.table_name, '.', '_') || '.' || REPLACE(target_column.column_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'COLUMN' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_') || '.' || REPLACE(base_data.source_column_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.columns target_column
INNER JOIN base_data ON base_data.target_column_id = target_column.column_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = base_data.source_table_id
WHERE target_column.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND base_data.target_column_id IS NOT NULL
AND UPPER(target_column.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION 

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'COLUMN' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_') || '.' || REPLACE(base_data.source_column_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN base_data ON base_data.target_table_id = target_table.table_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = base_data.source_table_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'TABLE' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN base_data ON base_data.target_table_id = target_table.table_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = base_data.source_table_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')

UNION 

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'COLUMN' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_column.table_catalog, '.', '_') || '.' || REPLACE(source_column.table_schema, '.', '_') || '.' || REPLACE(source_column.table_name, '.', '_') || '.' || REPLACE(source_column.column_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN ddl_data ON ddl_data.target_table_id = target_table.table_id
INNER JOIN account_usage.columns source_column ON source_column.column_id = ddl_data.column_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_column.table_schema != 'INFORMATION_SCHEMA'
AND ddl_data.column_id IS NOT NULL
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_column.table_catalog) IN ('{1}')

UNION

SELECT DISTINCT
    'TABLE' AS "SRC_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(target_table.table_catalog, '.', '_') || '.' || REPLACE(target_table.table_schema, '.', '_') || '.' || REPLACE(target_table.table_name, '.', '_')) AS "SRC_OBJECT_ID", 
    'TABLE' AS "TRG_OBJECT_TYPE",
    LOWER('{0}.' || REPLACE(source_table.table_catalog, '.', '_') || '.' || REPLACE(source_table.table_schema, '.', '_') || '.' || REPLACE(source_table.table_name, '.', '_')) AS "TRG_OBJECT_ID",
    'REFERENCES' AS "RELATIONSHIP"
FROM account_usage.tables target_table
INNER JOIN ddl_data ON ddl_data.target_table_id = target_table.table_id
INNER JOIN account_usage.columns source_column ON source_column.column_id = ddl_data.column_id
INNER JOIN account_usage.tables source_table ON source_table.table_id = source_column.table_id
WHERE target_table.table_schema != 'INFORMATION_SCHEMA'
AND source_table.table_schema != 'INFORMATION_SCHEMA'
AND source_column.table_schema != 'INFORMATION_SCHEMA'
AND ddl_data.column_id IS NOT NULL
AND UPPER(target_table.table_catalog) IN ('{1}')
AND UPPER(source_table.table_catalog) IN ('{1}')
"""
}