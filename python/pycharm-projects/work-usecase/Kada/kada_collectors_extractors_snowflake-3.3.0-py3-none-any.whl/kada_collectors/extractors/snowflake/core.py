import snowflake.connector
import os
import copy
import shutil
import logging
from distutils.dir_util import copy_tree
from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from ..models import DatabaseLog, DatabaseMetadata, DatabaseDdl, DatabaseDdlMetadata, DatabaseMetadataKeys, Meta, Links, Role, Properties
from ..masker import mask as masker
from ..base import BaseExtractor, ExtractorException
from .sql import DB_SQL

logger = logging.getLogger(__name__)
logging.getLogger('snowflake.connector').setLevel(logging.WARNING) # Suppress Snowflake Logging

class Extractor(BaseExtractor):
    def __init__(self, account: str=None, username: str=None, password: str=None, databases: list=[], information_database: str='snowflake', role: str='accountadmin', output_path: str='./output', warehouse: str=None, login_timeout: int=5, mask: bool=False, compress: bool=False, host: str=None, use_private_key: bool=False, private_key: str=None, enterprise: bool=True):
        """
        account: snowflake account
        username: username to sign into snowflake
        password: password to sign into snowflake or the password for the private key if using private key
        information_database: database with snowflake level information
        databases: list of databases to extract
        role: role with access to the database with snowflake level information
        output_path: full or relative path to where the outputs should go
        warehouse: specify a different warehouse if required, otherwise the default will be used
        login_timeout: The timeout for snowflake Auth
        mask: To mask the META/DATABASE_LOG files or not
        compress: To gzip output files or not
        host: The host value onboarded in K
        use_private_key: Using private/public RSA keys 
        private_key: the private key value in plain text not byte encoded
        enterprise: Are you using snowflake enterprise edition
        """
        self.ver = '3.3.0'
        self.host = host
        self.account = account
        self.username = username
        self.password = password
        self.databases = databases
        self.information_database = information_database
        self.role = role
        self.output_path = output_path
        self.mask = mask
        self.warehouse = warehouse
        self.login_timeout = login_timeout
        self.compress = compress
        self.sql = copy.deepcopy(DB_SQL)
        self.use_private_key = use_private_key
        self.private_key = private_key
        self.enterprise = enterprise

        additional_logger_info = ''
        if self.use_private_key:
            additional_logger_info = f"""
                use_private_key = {self.use_private_key}
                private_key = ******"""
            if not self.private_key:
                raise ExtractorException('use_private_key was specified to be true but not private key value was provided')

        logger.info(
            f"""
            =====
            Utilising extractor ver {self.ver} with the following parameters
                account = {self.account}
                username = {self.username}
                password = ******
                databases = {self.databases}
                information_database = {self.information_database}
                role = {self.role}
                warehouse = {self.warehouse}
                login_timeout = {self.login_timeout}
                output_path = {self.output_path}
                mask = {self.mask}
                compress = {self.compress}{additional_logger_info}
                enterprise = {self.enterprise}
            =====
            """
        )

    def get_connection(self):
        warehouse_kwargs = { 'warehouse': self.warehouse } if self.warehouse else {}
        if self.use_private_key:
            p_key = serialization.load_pem_private_key(
                self.private_key.encode(),
                password=self.password.encode() if self.password else None,
                backend=default_backend()
            )
            return snowflake.connector.connect(
                user=self.username,
                private_key=p_key.private_bytes(
                    encoding=serialization.Encoding.DER,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                ),
                account=self.account,
                database=self.information_database,
                role=self.role,
                **warehouse_kwargs,
                login_timeout=self.login_timeout,
                client_session_keep_alive=True
            )
        else:
            return snowflake.connector.connect(
                user=self.username,
                password=self.password,
                account=self.account,
                database=self.information_database,
                role=self.role,
                **warehouse_kwargs,
                login_timeout=self.login_timeout,
                client_session_keep_alive=True
            )

    def test_connection(self):
        """
        Basic connection test to the source
        """
        logger.info('Testing connection')
        try:
            with self.get_connection() as con: # KEEP ALIVE is set to true so make sure we manage the connection
                with con.cursor() as cur:
                    cur.execute('SELECT * FROM account_usage.databases LIMIT 1')
        except Exception as exp:
            logger.error('Unable to connect to the database.')
            raise exp

    def run(self, start_hwm: str=None, end_hwm: str=None):
        """
        start_hwm: Start range for event filtering, timestamp in format YYYY-MM-DD HH:MM:SS
        end_hwm: End range for event filtering, timestamp in format YYYY-MM-DD HH:MM:SS
        """
        logger.info("Extraction starting")
        if not start_hwm or not end_hwm:
            raise ExtractorException('The start_hwm and end_hwm must be specified')
        if not self.databases:
            raise ExtractorException('No databases have been specified')

        ############ Connection
        with self.get_connection() as con: # KEEP ALIVE is set to true so make sure we manage the connection
            logger.info("Connected to database: {}".format(self.information_database))
            if self.warehouse:
                logger.info("Using warehouse: {}".format(self.warehouse))
            else:
                logger.info("Using warehouse: Snowflake Default (Check your snowflake settings for this)")

            cur = con.cursor()
            cur.execute("ALTER SESSION SET TIMEZONE = 'UTC'")
            ############ END Connection

            date_suffix = datetime.now().strftime('%Y%m%d%H%M%S')
            if os.path.exists(self.output_path):
                shutil.rmtree(self.output_path)
            os.makedirs(self.output_path, exist_ok=True)
            # Create a /tmp folder in the output path to temporarily place the pre-masked set
            tmp_output_path = self.output_path + '/tmp'
            if self.mask:
                os.makedirs(tmp_output_path, exist_ok=True)

            db_list = "','".join([db.strip() for db in self.databases]).upper() # Incase there is white space get rid of it

            logger.info('Extracting Database from {} to {}'.format(start_hwm, end_hwm))
            logger.info('Following databases in scope:\n{}'.format('\n'.join(self.databases)))
            dblog = DatabaseLog(date_suffix, filepath=self.output_path, compress=self.compress)
            dblog.execute_write_close(cur, self.sql['DATABASE_LOGS_SQL'].format(start_hwm, end_hwm))
            meta = Meta(date_suffix, filepath=self.output_path, compress=self.compress)
            querys = self.sql['META_SQL'].format(start_hwm, end_hwm).split(';')
            cur.execute(querys[0]).fetchall()
            meta.execute_write_close(cur, querys[1])
            links = Links(date_suffix, filepath=self.output_path, compress=self.compress)
            querys = self.sql['LINKAGE_SQL'].format(self.host.replace('.', '_'), start_hwm, end_hwm).split(';')
            cur.execute(querys[0]).fetchall()
            if self.enterprise: # Add the lineage extension query
                querys[1] = querys[1] + ' UNION ALL (' + self.sql['LINKAGE_EXT_SQL'].format(self.host.replace('.', '_'), db_list, start_hwm, end_hwm) + ')'
            links.execute_write_close(cur, querys[1])
            role = Role(date_suffix, filepath=self.output_path, compress=self.compress)
            role.execute_write_close(cur, self.sql['ROLES_SQL'].format(self.host.replace('.', '_')))
            properties = Properties(date_suffix, filepath=self.output_path, compress=self.compress)
            querys = self.sql['PROPERTIES_SQL'].format(self.host.replace('.', '_'), db_list).split(';')
            cur.execute(querys[0]).fetchall()
            properties.execute_write_close(cur, querys[1])
            dbmetadata = DatabaseMetadata(date_suffix, filepath=self.output_path, compress=self.compress)
            querys = self.sql['METADATA_SQL'].format(db_list).split(';')
            cur.execute(querys[0]).fetchall()
            dbmetadata.execute_write_close(cur, querys[1])
            dbddlmetadata = DatabaseDdlMetadata(date_suffix, filepath=self.output_path, compress=self.compress)
            dbddlmetadata.execute_write_close(cur, self.sql['DDL_METADATA_SQL'].format(db_list))
            dbddl = DatabaseDdl(date_suffix, filepath=self.output_path, compress=self.compress)
            dbddl.execute_write_close(cur, self.sql['DDL_SQL'].format(db_list))
            querys = self.sql['METADATA_KEYS_SQL'].format(db_list).split(';')
            cur.execute(querys[0]).fetchall()
            dbmetadatakeys = DatabaseMetadataKeys(date_suffix, filepath=self.output_path, compress=self.compress)
            dbmetadatakeys.execute_write_close(cur, querys[1])

            # Mask the relevant files that were directed to the tmp
            if self.mask:
                logger.info("Masking data as it was enabled")
                masker(input_path=self.output_path, output_path=tmp_output_path)
                copy_tree(tmp_output_path, self.output_path)
                shutil.rmtree(tmp_output_path)

            logger.info("Extraction complete")
            payload = {
                dblog.file_name_path: dblog.record_counter,
                meta.file_name_path: meta.record_counter,
                links.file_name_path: links.record_counter,
                role.file_name_path: role.record_counter,
                properties.file_name_path: properties.record_counter,
                dbmetadata.file_name_path: dbmetadata.record_counter,
                dbddlmetadata.file_name_path: dbddlmetadata.record_counter,
                dbddl.file_name_path: dbddl.record_counter,
                dbmetadatakeys.file_name_path: dbmetadatakeys.record_counter
            }
            for k,v in dblog.part_files.items():
                payload[k] = v
            return payload